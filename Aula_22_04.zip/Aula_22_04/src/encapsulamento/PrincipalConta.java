package encapsulamento;

public class PrincipalConta {
	public static void main(String[] args) {
		Conta c = new Conta();
		c.deposita(1000);
		c.saca(2000);
		System.out.println(c.getsaldo());
	}
}
