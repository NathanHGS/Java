package encapsulamento;

public class Pessoa {
	private String cpf;
	private String nome;
	private int idade;
	
	//Contrutores
	public Pessoa(String cpf, String nome, int idade) {
		this.cpf = cpf;
		this.nome = nome;
		this.idade = idade;
	}
	public Pessoa() {
	}
	public Pessoa(String nome) {
		this.nome = nome;
	}
	
	//Encapsulamento
	public void setCpf (String cpf) {
		this.cpf = cpf;
	}
	public void setNome (String nome) {
		this.nome = nome;
	}
	public void setIdade (int idade) {
		this.idade = idade;
	}
	public String getCpf() {
		return  this.cpf;
	}
	public String getNome() {
		return this.nome;
	}
	public int getIdade() {
		return this.idade;
	}
}
