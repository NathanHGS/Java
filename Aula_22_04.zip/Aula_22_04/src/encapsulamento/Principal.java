package encapsulamento;

public class Principal {
	public static void main(String[] args) {
		Pessoa p = new Pessoa();
		p.setCpf("111.111.111-11");
		p.setNome("Fulano da Silva");
		p.setIdade(40);
		System.out.println(p.getNome() + p.getCpf() + p.getIdade());
		Pessoa p1 = new Pessoa("222.222.222-22", "Ciclano", 50);
		Pessoa p2 = new Pessoa("Beltrano");
		System.out.println(p1.getNome());
		System.out.println(p2.getNome());
	}
}
