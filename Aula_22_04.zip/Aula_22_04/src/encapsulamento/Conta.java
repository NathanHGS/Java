package encapsulamento;

public class Conta {
	private double saldo;
	
	public double getsaldo() {
		return this.saldo;
	}
    public void setSaldo(double saldo){
		this.saldo = saldo;
	}
    public void deposita(double x){
			this.saldo = this.saldo + x;
	}
	public void saca (double x){
		this.saldo = this.saldo - x;
	}

}
