package exercicio;

public class Principal {
	public static void main(String[] args) {
		Armario arm = new Armario(1.20, 3.60, 67, false);
		arm.abrir();
		arm.fechar();
	}
}
