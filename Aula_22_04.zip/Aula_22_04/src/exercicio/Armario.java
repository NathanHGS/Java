package exercicio;

public class Armario {
	private double altura;
	private double largura;
	private int qtnLivros;
	private boolean aberto;
	
	
	//Construtores
	public Armario() {
	}
	public Armario(double altura, double largura, int qtnLivros, boolean aberto) {
		super();
		this.altura = altura;
		this.largura = largura;
		this.qtnLivros = qtnLivros;
		this.aberto = aberto;
	}
	
	
	//encapsulamento
		//Setters
	public void setAltura(double altura) {
		this.altura = altura;
	}
	public void setLargura(double largura) {
		this.largura = largura;
	}
	public void setQtnLivros(int qtnLivros) {
		this.qtnLivros = qtnLivros;
	}
	public void setAberto(boolean aberto) {
		this.aberto = aberto;
	}
	
		//Getters
	public double getAltura() {
		return altura;
	}
	public double getLargura() {
		return largura;
	}
	
	public int getQtnLivros() {
		return qtnLivros;
	}
	
	public boolean isAberto() {
		return aberto;
	}
	
	//metodos
	public void abrir () {
		if(this.aberto == true) {
			System.out.println("O arm�rio j� est� aberto.");
		}else {
			System.out.println("O arm�rio foi aberto.");
			this.aberto = true;
		}
	}
	public void fechar() {
		if(this.aberto == false) {
			System.out.println("O arm�rio j� est� fechado.");
		}else {
			System.out.println("O arm�rio foi fechado.");
			this.aberto = false;
		}
	}
	public void inserirLivros() {
		if()
	}
}
