package associacao.aeroporto;

public class Endereco {
	private String endereco;
	private int numero;
}
