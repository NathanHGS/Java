package associacao.aeroporto;

public class testaAeroporto {
	public static void main(String[] args) {
		Endereco end = new Endereco ("rua Tal", 10, "800000", "S�o Paulo");
		Aeroporto aer = new Aeroporto ("Cumbica");
	}
}
