package associacao.aeroporto;

public class Aeroporto {
	private String nome;
	private Endereco endereco;
	
	//construtores
	public Aeroporto(String nome) {
		this.nome = nome;
	}
	
	//Getters e Setters
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Endereco getEndereco() {
		return endereco;
	}

	public void setEndereco(Endereco endereco) {
		this.endereco = endereco;
	}

	@Override
	public String toString() {
		return "Aeroporto [nome=" + nome + ", endereco=" + endereco + "]";
	}
	
	
	
}
