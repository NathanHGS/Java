package associacao.casa;

import javax.swing.JOptionPane;

public class Porta {
	private boolean aberta;
	private String cor;
	
	//Construtores
	public Porta() {
	}
	public Porta(boolean aberta, String cor) {
		this.aberta = aberta;
		this.cor = cor;
	}
	
	//Getters e Setters
	public boolean isAberta() {
		return aberta;
	}
	public void setAberta(boolean aberta) {
		this.aberta = aberta;
	}
	public String getCor() {
		return cor;
	}
	public void setCor(String cor) {
		this.cor = cor;
	}
	//toString
	@Override
	public String toString() {
		return "Porta [aberta=" + aberta + ", cor=" + cor + "]";
	}
	//Metodos
	public void abre() {
		if(this.aberta == false) {
			this.aberta = true;
			JOptionPane.showMessageDialog(null, "A porta foi aberta!", "Abre a porta", JOptionPane.DEFAULT_OPTION);
		}else {
			JOptionPane.showMessageDialog(null, "N�o se pode abrir uma porta aberta!", "Abre a porta", JOptionPane.ERROR_MESSAGE);
		}
	}
	public void fecha() {
		if(this.aberta == true) {
			this.aberta = false;
			JOptionPane.showMessageDialog(null, "A porta foi Fechada!", "Fecha a porta", JOptionPane.DEFAULT_OPTION);
		}else {
			JOptionPane.showMessageDialog(null, "N�o se pode fechar uma porta fechada!", "Fecha a porta", JOptionPane.ERROR_MESSAGE);
		}
	}
	public void pinta() {
		String corzinha = JOptionPane.showInputDialog(null, "Qual a cor q deve ser pintada a porta?", "Pinta a porta", JOptionPane.QUESTION_MESSAGE);
		this.cor = corzinha;
	}
	public void estaAberta() {
	}
}
