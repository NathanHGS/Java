package associacao.casa;

public class testaCasa {
	public static void main(String[] args) {
		Porta p1 = new Porta (false, "Verde");
		Porta p2 = new Porta (true, "Amarelo");
		Porta p3 = new Porta (true, "Vermelho");
		Casa c = new Casa("Branca");
		c.setPorta1(p1);
		c.setPorta2(p2);
		c.setPorta3(p3);
		
		p1.abre();
		p1.fecha();
		p1.pinta();
		
		System.out.println(c);
	}
}
