package associacao.pais;

public class testaPais {
	public static void main(String[] args) {
		Pais pais = new Pais("Brasil", "BR", "990.000.000", " 8.516.000");
		Presidente p1 = new Presidente ("Bolsonaro", "123.456.789-0");
		pais.setPresidente(p1);
		
		System.out.println(pais);
	}
}
