package associacao.pais;

public class Pais {
	private String nome;
	private String sigla;
	private String numeroHabitantes;
	private String area;
	private Presidente presidente;
	
	//Construtores
	public Pais() {
	}
	public Pais(String nome, String sigla, String numeroHabitantes, String area) {
		this.nome = nome;
		this.sigla = sigla;
		this.numeroHabitantes = numeroHabitantes;
		this.area = area;
	}
	
	//Getters e Setters
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getSigla() {
		return sigla;
	}
	public void setSigla(String sigla) {
		this.sigla = sigla;
	}
	public String getNumeroHabitantes() {
		return numeroHabitantes;
	}
	public void setNumeroHabitantes(String numeroHabitantes) {
		this.numeroHabitantes = numeroHabitantes;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public Presidente getPresidente() {
		return presidente;
	}
	public void setPresidente(Presidente presidente) {
		this.presidente = presidente;
	}
	//toString
	@Override
	public String toString() {
		return "Pais [nome=" + nome + ", sigla=" + sigla + ", numeroHabitantes=" + numeroHabitantes + ", area=" + area
				+ ", presidente=" + presidente + "]";
	}
	
}

