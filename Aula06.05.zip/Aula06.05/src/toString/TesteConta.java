package toString;

public class TesteConta {
	public static void main(String[] args) {
		Conta c = new Conta ("Nathan", 2000, "123", "987654321");
		System.out.println(c);
		String s = "Fulano";
		if(c.getTitular().equals(s)) {
			System.out.println("Titular Nathan");
		}else {
			System.out.println(s);
		}
	}
}
