package toString;

public class Conta {
	private String titular;
	private double saldo;
	private String agencia;
	private String numeroConta;
	
	//Construtores
	public Conta(String t, double s, String a, String n) {
		titular = t;
		saldo = s;
		agencia = a;
		numeroConta = n;
	}
	public Conta() {
	}
	
	//Getters e Setters
	public String getTitular() {
		return titular;
	}
	public void setTitular(String titular) {
		this.titular = titular;
	}
	public double getSaldo() {
		return saldo;
	}
	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}
	public String getAgencia() {
		return agencia;
	}
	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}
	public String getNumeroConta() {
		return numeroConta;
	}
	public void setNumeroConta(String numeroConta) {
		this.numeroConta = numeroConta;
	}
	@Override
	public String toString() {
		return "Conta = " + numeroConta + ", Saldo " + saldo;
	}
	
	
}
