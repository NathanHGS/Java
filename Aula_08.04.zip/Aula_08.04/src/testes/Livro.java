package testes;

public class Livro {
	//atributos
	String isbn;
	String titulo;
	String autor;
	int numPaginas;
	boolean emprestado = false;
	//m�todos
	void escreveNomeLivro () {
		System.out.println(this.titulo);
	}
	int quantPaginas () {
		return this.numPaginas;
	}
	void emprestaLivro() {
		if(this.emprestado == true) {
			System.out.println("O livro j� est� emprestado.");
		}else {
			this.emprestado = true;
			System.out.println("Emprestimo feito");
		}
	}
	void devolveLivro() {
		if(this.emprestado == true) {
			this.emprestado = false;
			System.out.println("Livro foi devolvido");
		}else {
			System.out.println("O livro n�o est� emprestado");
		}
	}
}
