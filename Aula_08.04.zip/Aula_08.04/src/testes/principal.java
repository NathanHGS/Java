package testes;

public class principal {
	public static void main(String[] args) {
		Livro l1 = new Livro();
		l1.autor = "JRRTolkein";
		l1.titulo = "O Hobbit";
		l1.isbn = "sr1111222";
		l1.numPaginas = 315;
		Livro l2 = new Livro();
		l2.titulo = "Java: como programar";
		System.out.println(l2.quantPaginas());
		l2.escreveNomeLivro();
		System.out.println(l1.quantPaginas());
		l1.emprestaLivro();
		
	}
}
