package exercicios;

import java.util.Scanner;

public class Principal_Pessoa {
	public static void main(String[] args) {
		Scanner entrada = new Scanner (System.in);
		
		Pessoa pessoa = new Pessoa();
		//Perguntas
		System.out.println("Digite seu nome:");
		pessoa.nome = entrada.nextLine();
		System.out.println("Digite seu CPF:");
		pessoa.cpf = entrada.nextLine();
		System.out.println("Digite sua idade:");
		pessoa.idade = entrada.nextInt();
		//Metodos_executados
		pessoa.andando();
		pessoa.comendo();
		pessoa.dormindo();
		System.out.println(pessoa.mostraIdade());
		entrada.close();
	}
}
