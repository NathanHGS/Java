package exercicios;

public class Caneta {
	//atributos
	String cor;
	int tam;
	boolean tampada = true;
	//metodos
	void tampar() {
		if(this.tampada == false) {
			this.tampada = true;
			System.out.println("A caneta foi tampada");
		}else {
			System.out.println("A caneta j� est� tampada");
		}
	}
	void destampar() {
		if(this.tampada == true) {
			this.tampada = false;
			System.out.println("Caneta foi destampada");
		}else {
			System.out.println("A caneta ja est� destampada");
		}
	}
	void escrever() {
		if(this.tampada == false) {
			System.out.println("A caneta est� escrevendo");
		}else {
			System.out.println("N�o se pode escrever com uma caneta tampada");
		}
	}
}
