package exercicios;

import java.util.Scanner;

public class Principal_Canera {
	public static void main(String[] args) {
		Scanner entrada = new Scanner (System.in);
		Caneta caneta = new Caneta();
		System.out.println("Digite a cor da caneta:");
		caneta.cor = entrada.nextLine();
		System.out.println("Digite o tamanho da caneta:");
		caneta.tam = entrada.nextInt();
		
		caneta.tampar();
		caneta.destampar();
		caneta.escrever();
		entrada.close();
	}
}
