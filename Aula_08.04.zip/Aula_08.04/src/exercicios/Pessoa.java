package exercicios;

public class Pessoa {
	//atributos
	String nome;
	int idade;
	String cpf;
	boolean andar = false;
	boolean comer = false;
	boolean dormir = false;
	//metodos
	void andando () {
		if (this.andar == true) {
			System.out.println("Voc� est� andando");
		}else {
			this.andar = true;
			System.out.println("Voc� estava parado");
		}
	}
	void comendo () {
		if(this.comer == true) {
			System.out.println("Voc� est� comendo");
		}else {
			this.comer = true;
			System.out.println("Voc� n�o etava comendo");
		}
	}
	void dormindo () {
		if(this.dormir == true) {
			System.out.println("Voc� est� dormindo");
		}else {
			this.dormir = true;
			System.out.println("Voc� estava acordado");
		}
	}
	int mostraIdade () {
		return this.idade;
	}
}
