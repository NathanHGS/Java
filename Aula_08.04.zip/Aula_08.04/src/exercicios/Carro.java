package exercicios;

public class Carro {
	//atributos
	String modelo;
	String marca;
	int ano;
	boolean ligado = false;
	//metodos
	void ligar() {
		if(this.ligado == false) {
			this.ligado = true;
			System.out.println("O carros foi ligado");
			
		}else {
			System.out.println("O carro j� estava ligado");
		}
	}
	void desligar() {
		if(this.ligado == true) {
			this.ligado = false;
			System.out.println("O carros foi desligado");
		}
	}
	void andarFrente() {
		if(this.ligado == true) {
			System.out.println("Carro andando para frente");
		}else {
			System.out.println("N�o � possivel andar com o carro desligado");
		}
	}
	void andartras() {
		if(this.ligado == true) {
			System.out.println("Carro andando para tr�s");
		}else {
			System.out.println("N�o � possivel andar com o carro desligado");
		}
	}
}
