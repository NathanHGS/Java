package exercicio;

public class Remedio {
	private String nome;
	private int qtdDias;
	private int idadePermitida;
	//Contrutores
	public Remedio() {
	}
	public Remedio(String nome, int qtdDias, int idadePermitida) {
		this.nome = nome;
		this.qtdDias = qtdDias;
		this.idadePermitida = idadePermitida;
	}
	//Getters e Setters
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getQtdDias() {
		return qtdDias;
	}
	public void setQtdDias(int qtdDias) {
		this.qtdDias = qtdDias;
	}
	public int getIdadePermitida() {
		return idadePermitida;
	}
	public void setIdadePermitida(int idadePermitida) {
		this.idadePermitida = idadePermitida;
	}
	//toString
	@Override
	public String toString() {
		return "Remedio [nome=" + nome + ", qtdDias=" + qtdDias + ", idadePermitida=" + idadePermitida + "]";
	}
	
}
