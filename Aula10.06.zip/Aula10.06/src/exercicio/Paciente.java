package exercicio;

import java.util.ArrayList;

public class Paciente {
	private String nome;
	private int idade;
	private ArrayList<Remedio> remedios;
	//Contrutores
	public Paciente() {
		this.remedios = new ArrayList<>();
	}
	public Paciente(String nome, int idade) {
		this.nome = nome;
		this.idade = idade;
		this.remedios = new ArrayList<>();
	}
	//Getters e Setters
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getIdade() {
		return idade;
	}
	public void setIdade(int idade) {
		this.idade = idade;
	}
	public ArrayList<Remedio> getRemedios() {
		return remedios;
	}
	public void setRemedios(ArrayList<Remedio> remedios) {
		this.remedios = remedios;
	}
	//toString
	@Override
	public String toString() {
		return "Paciente [nome=" + nome + ", idade=" + idade + ", remedios=" + remedios + "]";
	}
	//Metodos
	public void addRemedio(Remedio r) {
		int i = r.getIdadePermitida();
		if(idade >= i) {
			remedios.add(r);
		}else {
			System.out.println("Voc� n�o tem idade necess�ria!");
		}
		
	}
	
}
