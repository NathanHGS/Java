package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;

public class TelaPrincipal extends JFrame {

	private JPanel contentPane;
	private JTable tabela_aluno;
	private JTextField codigo;
	private JTextField nome;
	private JTextField email;
	private JTextField telefone;
	private JTable tabela_turma;
	private JTextField codigo_turma;
	private JTextField sala;
	private JTextField horario;
	private JTextField codAluno;
	private JTextField codTurma;
	private JTextField apareceTexto;
	private JTextField cod;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelaPrincipal frame = new TelaPrincipal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TelaPrincipal() {
		ArrayList <Aluno> alunos = new ArrayList<>();
		ArrayList <Turma> turmas = new ArrayList<>();
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(10, 11, 414, 240);
		contentPane.add(tabbedPane);
		
		JPanel panel = new JPanel();
		tabbedPane.addTab("Aluno", null, panel, null);
		panel.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(40, 11, 332, 88);
		panel.add(scrollPane);
		
		tabela_aluno = new JTable();
		tabela_aluno.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"C\u00F3digo", "Nome", "E-mail", "Telefone"
			}
		) {
			Class[] columnTypes = new Class[] {
				Integer.class, String.class, String.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		tabela_aluno.getColumnModel().getColumn(0).setPreferredWidth(93);
		scrollPane.setViewportView(tabela_aluno);
		
		JLabel lblCdigo = new JLabel("C\u00F3digo");
		lblCdigo.setBounds(40, 110, 46, 14);
		panel.add(lblCdigo);
		
		JLabel lblNewLabel = new JLabel("Nome");
		lblNewLabel.setBounds(40, 135, 46, 14);
		panel.add(lblNewLabel);
		
		JLabel lblEmail = new JLabel("E-mail");
		lblEmail.setBounds(40, 160, 46, 14);
		panel.add(lblEmail);
		
		JLabel lblTelefone = new JLabel("Telefone");
		lblTelefone.setBounds(40, 185, 46, 14);
		panel.add(lblTelefone);
		
		codigo = new JTextField();
		codigo.setBounds(102, 110, 86, 20);
		panel.add(codigo);
		codigo.setColumns(10);
		
		nome = new JTextField();
		nome.setBounds(102, 132, 86, 20);
		panel.add(nome);
		nome.setColumns(10);
		
		email = new JTextField();
		email.setBounds(102, 157, 86, 20);
		panel.add(email);
		email.setColumns(10);
		
		telefone = new JTextField();
		telefone.setBounds(102, 182, 86, 20);
		panel.add(telefone);
		telefone.setColumns(10);
		
		JButton btnInserir = new JButton("Inserir");
		btnInserir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int c = Integer.parseInt(codigo.getText());
				String n = nome.getText();
				String e = email.getText();
				String t = telefone.getText();
				Aluno a = new Aluno(c, n, e, t);
				alunos.add(a);
				DefaultTableModel model = (DefaultTableModel) tabela_aluno.getModel();
				model.addRow(new Object[] {c, n, e, t});
			}
		});
		btnInserir.setBounds(261, 151, 89, 23);
		panel.add(btnInserir);
		
		JPanel panel_1 = new JPanel();
		tabbedPane.addTab("Turma", null, panel_1, null);
		panel_1.setLayout(null);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(10, 11, 389, 67);
		panel_1.add(scrollPane_1);
		
		tabela_turma = new JTable();
		tabela_turma.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"C\u00F3digo", "Sala", "Hor\u00E1rio"
			}
		) {
			Class[] columnTypes = new Class[] {
				Integer.class, Integer.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		scrollPane_1.setViewportView(tabela_turma);
		
		JLabel lblCdigo_1 = new JLabel("C\u00F3digo");
		lblCdigo_1.setBounds(10, 94, 46, 14);
		panel_1.add(lblCdigo_1);
		
		JLabel lblSala = new JLabel("Sala");
		lblSala.setBounds(10, 119, 46, 14);
		panel_1.add(lblSala);
		
		JLabel lblHorrio = new JLabel("Hor\u00E1rio");
		lblHorrio.setBounds(10, 144, 46, 14);
		panel_1.add(lblHorrio);
		
		codigo_turma = new JTextField();
		codigo_turma.setBounds(86, 91, 86, 20);
		panel_1.add(codigo_turma);
		codigo_turma.setColumns(10);
		
		sala = new JTextField();
		sala.setBounds(86, 116, 86, 20);
		panel_1.add(sala);
		sala.setColumns(10);
		
		horario = new JTextField();
		horario.setBounds(86, 141, 86, 20);
		panel_1.add(horario);
		horario.setColumns(10);
		
		JButton btnNewButton = new JButton("Inserir");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int ct = Integer.parseInt(codigo_turma.getText());
				int s = Integer.parseInt(sala.getText());
				String h = horario.getText();
				Turma t = new Turma(ct, s, h);
				turmas.add(t);
				DefaultTableModel model_turma = (DefaultTableModel) tabela_turma.getModel();
				model_turma.addRow(new Object[] {ct, s, h});
			}
		});
		btnNewButton.setBounds(249, 119, 89, 23);
		panel_1.add(btnNewButton);
		
		JPanel panel_2 = new JPanel();
		tabbedPane.addTab("Associa Aluno/Turma", null, panel_2, null);
		panel_2.setLayout(null);
		
		JLabel c_aluno = new JLabel("C\u00F3digo aluno:");
		c_aluno.setBounds(36, 34, 71, 14);
		panel_2.add(c_aluno);
		
		codAluno = new JTextField();
		codAluno.setBounds(155, 31, 86, 20);
		panel_2.add(codAluno);
		codAluno.setColumns(10);
		
		JLabel c_turma = new JLabel("C\u00F3digo Turma:");
		c_turma.setBounds(36, 81, 71, 14);
		panel_2.add(c_turma);
		
		codTurma = new JTextField();
		codTurma.setBounds(155, 78, 86, 20);
		panel_2.add(codTurma);
		codTurma.setColumns(10);
		
		JButton btnAssociar = new JButton("Associar");
		btnAssociar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int c = Integer.parseInt(codAluno.getText());
				int ct = Integer.parseInt(codTurma.getText());
				int achouA = -1;
				int achouT = -1;
				for(int i = 0; i < alunos.size(); i++) {
					if(alunos.get(i).getCodAluno() == c) {
						achouA = i;
					}
				}
				for(int j = 0;j < turmas.size();j++) {
					if(turmas.get(j).getCodTurma() == ct) {
						achouT = j;
					}
				}
				if(achouA == -1 || achouT == -1) {
					JOptionPane.showMessageDialog(null, "Aluno ou turma n�o existe", "Erro", JOptionPane.ERROR_MESSAGE);
				}else {
					turmas.get(achouT).addAluno(alunos.get(achouA));
				}
			}
		});
		btnAssociar.setBounds(128, 139, 89, 23);
		panel_2.add(btnAssociar);
		
		JPanel panel_3 = new JPanel();
		tabbedPane.addTab("Listar Turma", null, panel_3, null);
		panel_3.setLayout(null);
		
		apareceTexto = new JTextField();
		apareceTexto.setBounds(26, 153, 342, 20);
		panel_3.add(apareceTexto);
		apareceTexto.setColumns(10);
		
		JButton btnMostrarTurma = new JButton("Mostrar turma");
		btnMostrarTurma.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int ct = Integer.parseInt(cod.getText());
				int turmaProc = -1;
				for(int i = 0; i < turmas.size(); i++) {
					if(turmas.get(i).getCodTurma() == ct) {
						turmaProc = i;
					}
				}
				if(turmaProc == -1) {
					JOptionPane.showMessageDialog(null,"Turma n�o existe.");
				}else {
					apareceTexto.setText(turmas.get(turmaProc).toString());
				}
				
			}
		});
		btnMostrarTurma.setBounds(141, 97, 101, 23);
		panel_3.add(btnMostrarTurma);
		
		cod = new JTextField();
		cod.setBounds(141, 44, 86, 20);
		panel_3.add(cod);
		cod.setColumns(10);
		
		JLabel lblCdigoTurma = new JLabel("C\u00F3digo turma");
		lblCdigoTurma.setBounds(38, 47, 64, 14);
		panel_3.add(lblCdigoTurma);
	}
}
