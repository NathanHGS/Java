package view;

import java.util.ArrayList;

public class Turma {
	private int codTurma;
	private int sala;
	private String horario;
	private ArrayList <Aluno> alunos;
	//Construtores
	public Turma() {
		this.alunos = new ArrayList<>();
	}
	public Turma(int codTurma, int sala, String horario) {
		this.codTurma = codTurma;
		this.sala = sala;
		this.horario = horario;
		this.alunos = new ArrayList<>();
	}
	//Getters e Setters
	public int getCodTurma() {
		return codTurma;
	}
	public void setCodTurma(int codTurma) {
		this.codTurma = codTurma;
	}
	public int getSala() {
		return sala;
	}
	public void setSala(int sala) {
		this.sala = sala;
	}
	public String getHorario() {
		return horario;
	}
	public void setHorario(String horario) {
		this.horario = horario;
	}
	public ArrayList<Aluno> getAlunos() {
		return alunos;
	}
	public void setAlunos(ArrayList<Aluno> alunos) {
		this.alunos = alunos;
	}
	//Metodos
	public void addAluno(Aluno a) {
		alunos.add(a);
	}
	//toString
	@Override
	public String toString() {
		return "Turma [codTurma=" + codTurma + ", sala=" + sala + ", horario=" + horario + ", alunos=" + alunos + "]";
	}
	
}
