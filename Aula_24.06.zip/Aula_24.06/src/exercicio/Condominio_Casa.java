package exercicio;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Condominio_Casa extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JTextField nome;
	private JTextField qtdCasa;
	private JTextField cidade;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Condominio_Casa frame = new Condominio_Casa();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Condominio_Casa() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(10, 11, 414, 240);
		contentPane.add(tabbedPane);
		
		JPanel panel = new JPanel();
		tabbedPane.addTab("Condominio", null, panel, null);
		panel.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 11, 389, 68);
		panel.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Nome", "Quantidade de Casa", "Cidade", "Casas"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, Integer.class, String.class, Object.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		
		JLabel lblNewLabel = new JLabel("Nome:");
		lblNewLabel.setBounds(92, 92, 46, 14);
		panel.add(lblNewLabel);
		
		JLabel lblQuanitdadeDeCasa = new JLabel("Quanitdade de Casa:");
		lblQuanitdadeDeCasa.setBounds(92, 117, 108, 14);
		panel.add(lblQuanitdadeDeCasa);
		
		JLabel lblCidade = new JLabel("Cidade:");
		lblCidade.setBounds(92, 142, 46, 14);
		panel.add(lblCidade);
		
		nome = new JTextField();
		nome.setBounds(269, 89, 86, 20);
		panel.add(nome);
		nome.setColumns(10);
		
		qtdCasa = new JTextField();
		qtdCasa.setBounds(269, 114, 86, 20);
		panel.add(qtdCasa);
		qtdCasa.setColumns(10);
		
		cidade = new JTextField();
		cidade.setBounds(269, 139, 86, 20);
		panel.add(cidade);
		cidade.setColumns(10);
		
		JButton btnCriar = new JButton("Inserir");
		btnCriar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String n = nome.getText();
				String q = qtdCasa.getText();
				int qtd = Integer.parseInt(q);
				String c = cidade.getText();
			}
		});
		btnCriar.setBounds(43, 178, 89, 23);
		panel.add(btnCriar);
		
		JButton btnRemove = new JButton("Remove");
		btnRemove.setBounds(152, 178, 89, 23);
		panel.add(btnRemove);
		
		JButton btnAlterar = new JButton("Alterar");
		btnAlterar.setBounds(269, 178, 89, 23);
		panel.add(btnAlterar);
		table.getColumnModel().getColumn(1).setPreferredWidth(115);
		
		JPanel panel_1 = new JPanel();
		tabbedPane.addTab("Casa", null, panel_1, null);
		
		JPanel panel_2 = new JPanel();
		tabbedPane.addTab("Associacao Casa Condominio", null, panel_2, null);
		
		JPanel panel_3 = new JPanel();
		tabbedPane.addTab("Listar casas", null, panel_3, null);
	}
}
