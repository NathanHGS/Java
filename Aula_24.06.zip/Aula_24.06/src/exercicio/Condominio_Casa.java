package exercicio;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;

public class Condominio_Casa extends JFrame {

	private JPanel contentPane;
	private JTable table;
	private JTextField nome;
	private JTextField qtdCasa;
	private JTextField cidade;
	private JTable table_1;
	private JTextField numero;
	private JTextField nome_proprietario;
	private JTextField area;
	private JTable table_2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Condominio_Casa frame = new Condominio_Casa();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Condominio_Casa() {
		
		ArrayList<Condominio> condominios = new ArrayList<>(); 
		ArrayList<Casa> casas = new ArrayList<>();
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 447, 298);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(10, 11, 414, 240);
		contentPane.add(tabbedPane);
		
		JPanel panel = new JPanel();
		tabbedPane.addTab("Condominio", null, panel, null);
		panel.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 11, 389, 68);
		panel.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Nome", "Quantidade de Casa", "Cidade"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, Integer.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		table.getColumnModel().getColumn(1).setPreferredWidth(115);
		
		JLabel lblNewLabel = new JLabel("Nome:");
		lblNewLabel.setBounds(92, 92, 46, 14);
		panel.add(lblNewLabel);
		
		JLabel lblQuanitdadeDeCasa = new JLabel("Quanitdade de Casa:");
		lblQuanitdadeDeCasa.setBounds(92, 117, 108, 14);
		panel.add(lblQuanitdadeDeCasa);
		
		JLabel lblCidade = new JLabel("Cidade:");
		lblCidade.setBounds(92, 142, 46, 14);
		panel.add(lblCidade);
		
		nome = new JTextField();
		nome.setBounds(269, 89, 86, 20);
		panel.add(nome);
		nome.setColumns(10);
		
		qtdCasa = new JTextField();
		qtdCasa.setBounds(269, 114, 86, 20);
		panel.add(qtdCasa);
		qtdCasa.setColumns(10);
		
		cidade = new JTextField();
		cidade.setBounds(269, 139, 86, 20);
		panel.add(cidade);
		cidade.setColumns(10);
		
		JButton btnCriar = new JButton("Inserir");
		btnCriar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String n = nome.getText();
				String q = qtdCasa.getText();
				int qtd = Integer.parseInt(q);
				String c = cidade.getText();
				Condominio con = new Condominio(n, qtd, c);
				for(int i = 0; i <= condominios.size()-1; i++) {
					if(con.getNome().equals(condominios.get(i).getNome())) {
						if(con.getCidade().equals(condominios.get(i).getCidade())) {
							JOptionPane.showMessageDialog(null, "Condominio ja existe nessa cidade!");
							return;
						}
					}
				}
				condominios.add(con);
				JOptionPane.showMessageDialog(null, "Condominio criado com sucesso!");
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				model.addRow(new Object [] {n, qtd, c});
			}
		});
		btnCriar.setBounds(43, 178, 89, 23);
		panel.add(btnCriar);
		
		JButton btnRemove = new JButton("Remove");
		btnRemove.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String n = nome.getText();
				String c = cidade.getText();
				for(int i = 0; i <= condominios.size()-1; i++) {
					if(n.equals(condominios.get(i).getNome())) {
						if(c.equals(condominios.get(i).getCidade())) {
							JOptionPane.showMessageDialog(null, "Condominio removido com sucesso!");
							condominios.remove(i);
							DefaultTableModel model = (DefaultTableModel) table.getModel();
							model.removeRow(i);
							return;
						}
					}
				}
				JOptionPane.showMessageDialog(null, "Esse condominio n�o existe!");
			}
		});
		btnRemove.setBounds(152, 178, 89, 23);
		panel.add(btnRemove);
		
		JButton btnAlterar = new JButton("Alterar");
		btnAlterar.setBounds(269, 178, 89, 23);
		panel.add(btnAlterar);
		
		JPanel panel_1 = new JPanel();
		tabbedPane.addTab("Casa", null, panel_1, null);
		panel_1.setLayout(null);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(10, 11, 389, 69);
		panel_1.add(scrollPane_1);
		
		table_1 = new JTable();
		table_1.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"N\u00FAmero", "Nome do Propriet\u00E1rio", "\u00C1rea"
			}
		) {
			Class[] columnTypes = new Class[] {
				Integer.class, String.class, Double.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		table_1.getColumnModel().getColumn(1).setPreferredWidth(120);
		scrollPane_1.setViewportView(table_1);
		
		JLabel lblNmero = new JLabel("N\u00FAmero:");
		lblNmero.setBounds(55, 94, 46, 14);
		panel_1.add(lblNmero);
		
		JLabel lblNomeDoProprietrio = new JLabel("Nome do Propriet\u00E1rio:");
		lblNomeDoProprietrio.setBounds(55, 121, 111, 14);
		panel_1.add(lblNomeDoProprietrio);
		
		JLabel lblrea = new JLabel("\u00C1rea:");
		lblrea.setBounds(55, 143, 46, 14);
		panel_1.add(lblrea);
		
		numero = new JTextField();
		numero.setBounds(269, 91, 86, 20);
		panel_1.add(numero);
		numero.setColumns(10);
		
		nome_proprietario = new JTextField();
		nome_proprietario.setBounds(269, 118, 86, 20);
		panel_1.add(nome_proprietario);
		nome_proprietario.setColumns(10);
		
		area = new JTextField();
		area.setBounds(269, 150, 86, 20);
		panel_1.add(area);
		area.setColumns(10);
		
		JButton btnInserir = new JButton("Inserir");
		btnInserir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String n = numero.getText();
				int num = Integer.parseInt(n);
				String np = nome_proprietario.getText();
				String ar = area.getText();
				double a = Double.parseDouble(ar);
				Casa c = new Casa(num, np, a);
				for(int i = 0; i <= casas.size()-1; i++) {
					if(c.getNum_casa() == casas.get(i).getNum_casa()) {
						
					}
				}
			}
		});
		btnInserir.setBounds(40, 178, 89, 23);
		panel_1.add(btnInserir);
		
		JButton btnRemover = new JButton("Remover");
		btnRemover.setBounds(159, 178, 89, 23);
		panel_1.add(btnRemover);
		
		JButton btnAlterar_1 = new JButton("Alterar");
		btnAlterar_1.setBounds(266, 178, 89, 23);
		panel_1.add(btnAlterar_1);
		
		JPanel panel_2 = new JPanel();
		tabbedPane.addTab("Associa\u00E7\u00E3o", null, panel_2, null);
		
		JPanel panel_3 = new JPanel();
		tabbedPane.addTab("Listar casas", null, panel_3, null);
		panel_3.setLayout(null);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(10, 11, 389, 76);
		panel_3.add(scrollPane_2);
		
		table_2 = new JTable();
		table_2.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
			}
		));
		scrollPane_2.setViewportView(table_2);
	}
}
