package exercicio;

import java.util.ArrayList;

import javax.swing.JOptionPane;

public class Condominio {
	private String nome;
	private int qtd_casa;
	private String cidade;
	private ArrayList<Casa> casas;
	//Construtores
	public Condominio() {
	}
	public Condominio(String nome, int qtd_casa, String cidade) {
		this.nome = nome;
		this.qtd_casa = qtd_casa;
		this.cidade = cidade;
		this.casas = new ArrayList<>();
	}
	//Getters e Setters
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getQtd_casa() {
		return qtd_casa;
	}
	public void setQtd_casa(int qtd_casa) {
		this.qtd_casa = qtd_casa;
	}
	public String getCidade() {
		return cidade;
	}
	public void setCidade(String cidade) {
		this.cidade = cidade;
	}
	public ArrayList<Casa> getCasas() {
		return casas;
	}
	public void setCasas(ArrayList<Casa> casas) {
		this.casas = casas;
	}
	//toString
	@Override
	public String toString() {
		return "Condominio [nome=" + nome + ", qtd_casa=" + qtd_casa + ", cidade=" + cidade + ", casas=" + casas + "]";
	}
	//Metodos
	public void addCasa(Casa c) {
		if(casas.size() > qtd_casa) {
			JOptionPane.showConfirmDialog(null, "Voc� n�o pode colocar mais casa nesse condominio!");
		}else {
			casas.add(c);
		}
		
	}
}
