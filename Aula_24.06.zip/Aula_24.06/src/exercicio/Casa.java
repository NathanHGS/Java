package exercicio;

public class Casa {
	private int num_casa;
	private String nome_proprietario;
	private double area_casa;
	//Construtores
	public Casa() {
	}
	public Casa(int num_casa, String nome_proprietario, double area_casa) {
		this.num_casa = num_casa;
		this.nome_proprietario = nome_proprietario;
		this.area_casa = area_casa;
	}
	//Getters e Setters
	public int getNum_casa() {
		return num_casa;
	}
	public void setNum_casa(int num_casa) {
		this.num_casa = num_casa;
	}
	public String getNome_proprietario() {
		return nome_proprietario;
	}
	public void setNome_proprietario(String nome_proprietario) {
		this.nome_proprietario = nome_proprietario;
	}
	public double getArea_casa() {
		return area_casa;
	}
	public void setArea_casa(double area_casa) {
		this.area_casa = area_casa;
	}
	//toString
	@Override
	public String toString() {
		return "Casa [num_casa=" + num_casa + ", nome_proprietario=" + nome_proprietario + ", area_casa=" + area_casa
				+ "]";
	}
}
